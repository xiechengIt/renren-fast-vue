<template>
  <div>
    <div style="font-size: 40px" align="center">
      <span>公司简介</span><br /><span style="font-size: 1.1rem; color: #999"
        >INTRODUCTION</span
      >
    </div>
    <!-- <div style="font-size: 20px" align="center">
      <div class="about_top">
        <p>
          &nbsp; &nbsp;
          宁波协诚电动工具有限公司，创办于1996年，公司位于风景秀丽的海港城市——浙江宁波奉化。占地面积16.60
          万平方米
        </p>
        <p>
          &nbsp; &nbsp;
          建筑面积约10万平方米，是一家专业生产电动工具的制造型企业，
          也是行业内规模较大的企业之一。
        </p>
        <p>
          &nbsp; &nbsp;
          现有员工1000余人，其中工程技术人员150余人，技术力量雄厚。公司总资产6.1亿元，
        </p>
        <p>
          &nbsp; &nbsp;
          其中固定资产1.1亿元。现代化的设备、科学的管理、强大的人才队伍共同打造了协诚这一强势品牌
        </p>

        <p style="text-align: center">
          <img
            style="width: 50%; display: block; margin: 0 auto"
            src="~@/assets/img/1588731410133493.jpg"
          />
        </p>
      </div>
    </div> -->

    <div class="e_box p_contentBox" loaded="true" data-infoid="1">
      <div class="e_box p_con">
        <div class="reset_style js-reset_style js-adapMobile">
          <p>
            <img
              alt="协诚电动"
              class="imageResponse js-onerror"
              id="928"
              src="~@/assets/img//YJi4T3ksTKuetch02yjRLg.jpg"
              style="
                width: 500px;
                height: 333px;
                float: right;
                margin-left: 45px;
              "
              title="协诚电动"
            />　　宁波协诚电动工具有限公司创办于1996年，公司位于风景秀丽的海港城市——浙江宁波奉化。占地面积16.60万平方米，建筑面积约10万平方米，是一家专业生产电动工具的制造型企业，也是行业内规模较大的企业之一。现有员工1000余人，其中工程技术人员150余人，技术力量雄厚。公司总资产6.1亿元，其中固定资产1.1亿元。现代化的设备、科学的管理、强大的人才队伍共同打造了协诚这一强势品牌。
          </p>
          <p>
            　　公司集产品设计、开发、生产、
            销售于一体。公司主导产品有：手持式工具系列、台式工具系列、园林工具系列、等100多种型号和规格。公司拥有国内先进的从电机转定子生产到整机成品出厂的一整套生产、检测设备。10条整机生产作业自动流水线，15条全自动电机生产流水线、日本进口的高速冲床，六工位转子自动平衡机，达到年生产电动工具电机400万套、整机350万套的生产规模。2008年，公司又投资450万元，引进瑞士进口大型激光切割设备.2014年陆续采购美国哈挺的加工中心、济南一机的数控磨床、湖北长机的数控插齿机等生产制造设备。在产品测试上有德国莱茵公司授权承认的EMC测试室、日本精密三次元检测设备、齿轮测量仪等。公司产品远销欧美等众多国家。
          </p>
          <img
            alt="协诚电动"
            class="imageResponse js-onerror"
            id="929"
            src="~@/assets/img//bNVzdVOkQt2JaFx02rlNhQ.jpg"
            style="
              width: 500px;
              height: 317px;
              float: left;
              margin-right: 45px;
              margin-top: 22px;
              margin-bottom: 22px;
            "
            title="协诚电动"
          />
          <p>
            　　协诚以规范的工艺流程、完善的配套设施和先进的检测设备，不断提高生产效率，保持了产品质量的高水准。1998年，协诚公司率先通过了ISO9000质量体系认证，IATF16949认证，协诚产品均通过了“GS”,“EMC”,“UL”,“CE”,“LCIE”
            认证。
          </p>
          <p>
            　　在追求外部发展的同时，协诚公司还全力加强整顿内部人力资源优势，推行“适才适岗”的用人原则，努力为员工创造充分展示才能的工作环境。通过不断的严格训练和奖惩分明的绩效考核，发掘员工潜力，引领公司攀登新的高峰。
          </p>
          <p>
            　　协诚公司将继续以客户为中心，用先进的企业管理理念和技术手段武装自己。通过ERP企业资源管理系统，PLM产品全生命周期管理系统、OA办公自动化系统等有效的整合企业资源，持之以恒的贯彻严格的质量管理方针，继续丰满和深化企业的文化，紧密的与客户结合成牢固的利益共同体和合作伙伴，不断创新、不断进步。
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style>
.mod-home {
  line-height: 1.5;
}
</style>

