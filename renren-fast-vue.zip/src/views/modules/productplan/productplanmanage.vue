<template>
  <div class="mod-config">
    <el-row :gutter="20">
      <el-col :span="6">
        <el-form
          :model="ruleForm"
          :rules="rules"
          ref="ruleForm"
          label-width="100px"
          class="demo-ruleForm"
        >
          <el-form-item label="产线id" prop="lineId">
            <el-select v-model="ruleForm.lineId" placeholder="请选择产线id">
              <el-option
                v-for="item in options"
                :key="item"
                :label="item"
                :value="item"
              ></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="品名" prop="productName">
            <el-input v-model="ruleForm.productName"></el-input>
          </el-form-item>
          <el-form-item label="规格" prop="specification">
            <el-input v-model="ruleForm.specification"></el-input>
          </el-form-item>
          <el-form-item label="料号" prop="partNum">
            <el-input v-model="ruleForm.partNum"></el-input>
          </el-form-item>
          <el-form-item label="订单号" prop="orderNum">
            <el-input v-model="ruleForm.orderNum"></el-input>
          </el-form-item>
          <el-form-item label="工单号" prop="workNum">
            <el-input v-model="ruleForm.workNum"></el-input>
          </el-form-item>
          <el-form-item label="生产计划量" prop="productPlanAmount">
            <el-input v-model="ruleForm.productPlanAmount"></el-input>
          </el-form-item>

          <el-form-item>
            <el-button type="primary" @click="submitForm('ruleForm')"
              >立即填写</el-button
            >
            <el-button @click="resetForm('ruleForm')">重置</el-button>
          </el-form-item>
        </el-form></el-col
      >
      <el-col :span="18"
        ><el-form
          :inline="true"
          :model="dataForm"
          @keyup.enter.native="getDataList()"
          @submit.native.prevent
        >
          <el-form-item>
            <el-input
              v-model="dataForm.key"
              placeholder="参数名"
              clearable
            ></el-input>
          </el-form-item>
          <el-form-item>
            <el-button @click="getDataList()">查询</el-button>
            <el-button type="primary" @click="addOrUpdateHandle()"
              >新增</el-button
            >
            <el-button
              type="danger"
              @click="deleteHandle()"
              :disabled="dataListSelections.length <= 0"
              >批量删除</el-button
            >
          </el-form-item>
        </el-form>
        <el-table
          :data="dataList"
          border
          v-loading="dataListLoading"
          @selection-change="selectionChangeHandle"
          style="width: 100%"
        >
          <el-table-column
            type="selection"
            header-align="center"
            align="center"
            width="50"
          >
          </el-table-column>
          <el-table-column
            prop="id"
            header-align="center"
            align="center"
            label="id"
          >
          </el-table-column>
          <el-table-column
            prop="lineId"
            header-align="center"
            align="center"
            label="装配线id"
          >
          </el-table-column>
          <el-table-column
            prop="productName"
            header-align="center"
            align="center"
            label="品名"
          >
          </el-table-column>
          <el-table-column
            prop="specification"
            header-align="center"
            align="center"
            label="规格"
          >
          </el-table-column>
          <el-table-column
            prop="partNum"
            header-align="center"
            align="center"
            label="料号"
          >
          </el-table-column>
          <el-table-column
            prop="orderNum"
            header-align="center"
            align="center"
            label="订单号"
          >
          </el-table-column>
          <el-table-column
            prop="workNum"
            header-align="center"
            align="center"
            label="工单号"
          >
          </el-table-column>
          <el-table-column
            prop="productPlanAmount"
            header-align="center"
            align="center"
            label="生产计划数量"
          >
          </el-table-column>
          <el-table-column
            prop="date"
            header-align="center"
            align="center"
            label="日期"
          >
          </el-table-column>
          <el-table-column
            fixed="right"
            header-align="center"
            align="center"
            width="150"
            label="操作"
          >
            <template slot-scope="scope">
              <el-button
                type="text"
                size="small"
                @click="addOrUpdateHandle(scope.row.id)"
                >修改</el-button
              >
              <el-button
                type="text"
                size="small"
                @click="deleteHandle(scope.row.id)"
                >删除</el-button
              >
            </template>
          </el-table-column>
        </el-table>
        <el-pagination
          @size-change="sizeChangeHandle"
          @current-change="currentChangeHandle"
          :current-page="pageIndex"
          :page-sizes="[10, 20, 50, 100]"
          :page-size="pageSize"
          :total="totalPage"
          layout="total, sizes, prev, pager, next, jumper"
        >
        </el-pagination>
        <!-- 弹窗, 新增 / 修改 -->
        <add-or-update
          v-if="addOrUpdateVisible"
          ref="addOrUpdate"
          @refreshDataList="getDataList"
        ></add-or-update>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import AddOrUpdate from "./productplanmanage-add-or-update";
export default {
  data() {
    return {
      dataForm: {
        key: "",
      },
      dataList: [],
      pageIndex: 1,
      pageSize: 10,
      totalPage: 0,
      dataListLoading: false,
      dataListSelections: [],
      addOrUpdateVisible: false,

      //计划编写提交
      ruleForm: {
        productName: "",
        specification: "",
        partNum: "",
        productPlanAmount: "",
        lineId: "",
        orderNum: "",
        workNum: "",
      },
      rules: {
        lineId: [
          { required: true, message: "请选择产线id", trigger: "change" },
        ],
        productName: [
          { required: true, message: "请输入品名", trigger: "blur" },
          ,
        ],
        specification: [
          { required: true, message: "请输入规格", trigger: "blur" },
          ,
        ],
        partNum: [
          { required: true, message: "请输入料号", trigger: "blur" },
          ,
        ],
        productPlanAmount: [
          { required: true, message: "请输入生产计划量", trigger: "blur" },
          ,
        ],
        orderNum: [
          { required: true, message: "请输入订单号", trigger: "blur" },
          ,
        ],
        workNum: [
          { required: true, message: "请输入工单号", trigger: "blur" },
          ,
        ],
      },
      options: [],
    };
  },
  components: {
    AddOrUpdate,
  },
  activated() {
    this.getDataList();

    this.getLineIds();
  },
  methods: {
    // 获取数据列表
    getDataList() {
      this.dataListLoading = true;
      this.$http({
        url: this.$http.adornUrl("/productionplan/productplanmanage/list"),
        method: "get",
        params: this.$http.adornParams({
          page: this.pageIndex,
          limit: this.pageSize,
          key: this.dataForm.key,
        }),
      }).then(({ data }) => {
        if (data && data.code === 0) {
          this.dataList = data.page.list;
          this.totalPage = data.page.totalCount;
        } else {
          this.dataList = [];
          this.totalPage = 0;
        }
        this.dataListLoading = false;
      });
    },
    // 每页数
    sizeChangeHandle(val) {
      this.pageSize = val;
      this.pageIndex = 1;
      this.getDataList();
    },
    // 当前页
    currentChangeHandle(val) {
      this.pageIndex = val;
      this.getDataList();
    },
    // 多选
    selectionChangeHandle(val) {
      this.dataListSelections = val;
    },
    // 新增 / 修改
    addOrUpdateHandle(id) {
      this.addOrUpdateVisible = true;
      this.$nextTick(() => {
        this.$refs.addOrUpdate.init(id);
      });
    },
    // 删除
    deleteHandle(id) {
      var ids = id
        ? [id]
        : this.dataListSelections.map((item) => {
            return item.id;
          });
      this.$confirm(
        `确定对[id=${ids.join(",")}]进行[${id ? "删除" : "批量删除"}]操作?`,
        "提示",
        {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        }
      ).then(() => {
        this.$http({
          url: this.$http.adornUrl("/productionplan/productplanmanage/delete"),
          method: "post",
          data: this.$http.adornData(ids, false),
        }).then(({ data }) => {
          if (data && data.code === 0) {
            this.$message({
              message: "操作成功",
              type: "success",
              duration: 1500,
              onClose: () => {
                this.getDataList();
              },
            });
          } else {
            this.$message.error(data.msg);
          }
        });
      });
    },

    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$http({
            url: this.$http.adornUrl("/productionplan/productplanmanage/save"),
            method: "post",
            data: this.$http.adornData({
              lineId: this.ruleForm.lineId,
              productName: this.ruleForm.productName,
              specification: this.ruleForm.specification,
              partNum: this.ruleForm.partNum,
              productPlanAmount: this.ruleForm.productPlanAmount,
              orderNum: this.ruleForm.orderNum,
              workNum: this.ruleForm.workNum,
              date: "",
            }),
          }).then(({ data }) => {
            if (data && data.code === 0) {
              let url =
                "http://localhost:8000/xiecheng/xiecheng/" +
                this.ruleForm.lineId;
              if (process.env.NODE_ENV == "production") {
                url =
                  "http://36.137.115.125:8000/xiecheng/xiecheng/" +
                  this.ruleForm.lineId;
              }
              window.open(url);
            } else {
              this.$message.error(data.msg);
            }
          });
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    getLineIds() {
      this.$http({
        url: this.$http.adornUrl("/productionplan/department/getLineIds"),
        method: "get",
      }).then(({ data }) => {
        console.log(data);
        if (data && data.code === 0) {
          this.options = data.lineIds;
        }
      });
    },
  },
};
</script>
